# eve-guard-magnite-418d19f5

Eve Guard PreToolUse + PostToolUse plugin for **Magnite**.

- Plugin version: `0.9.3+config.9036263b26578e9c`
- Hook source version: `0.9.3`
- Config hash: `9036263b26578e9c`
- Eve Guard URL: `https://magf29h8.guard.eve.security`
- Built at: `2026-08-12T16:53:27.451Z`

## Install

### Option A — Claude Code plugin marketplace (recommended)

This bundle ships a local marketplace manifest, so you can install it
with Claude Code's plugin commands. Unzip it, then from inside Claude
Code point a local marketplace at the unzipped folder and install:

```
/plugin marketplace add /path/to/eve-guard-magnite-418d19f5
/plugin install eve-guard-magnite-418d19f5@eve-guard-magnite-418d19f5-marketplace
```

Re-running `/plugin marketplace add` on a new download updates the entry;
`/plugin uninstall eve-guard-magnite-418d19f5@eve-guard-magnite-418d19f5-marketplace` removes it.

### Option B — Manual unzip / Cowork

Unzip into your Claude Code plugin directory (e.g. `~/.claude/plugins/eve-guard-magnite-418d19f5/`)
or hand the zip to Cowork via the plugin uploader.

## Configuration baked in

- Failure strategy: fail-open
- Per-attempt timeout: 10s
- Max retries on transient errors: 1
- Debug logging: off
- Disable curl transport: off
- Tool matcher pattern: `mcp__.*|Bash|Shell`

## Failure diagnostics

If the hook cannot reach Eve Guard or receives a non-2xx response, it fails closed and points Claude to the local diagnostics file:

- Windows: `%TEMP%\eve-guard-hook-diagnostics\last-failure.json`
- Windows history: `%TEMP%\eve-guard-hook-diagnostics\failures.jsonl`
- macOS/Linux: `${TMPDIR:-/tmp}/eve-guard-hook-diagnostics-$(id -u)/last-failure.json`
- macOS/Linux history: `${TMPDIR:-/tmp}/eve-guard-hook-diagnostics-$(id -u)/failures.jsonl`

Change any field in **Settings → Agent Hooks** and re-download to apply.
