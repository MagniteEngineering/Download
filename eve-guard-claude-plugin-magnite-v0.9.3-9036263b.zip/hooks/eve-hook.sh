#!/bin/sh

agent="${1:-claude-code}"
event_name="${2:-PreToolUse}"
retry_backoff_s="0.15"

env_value() {
  eval "value=\${$1:-}"
  if [ -n "$value" ]; then printf '%s' "$value"; else printf '%s' "$2"; fi
}

debug_log() {
  if [ "$(env_value EVE_HOOK_DEBUG "")" = "1" ]; then
    printf '%s\n' "[eve-hook] $1" >&2
  fi
}

json_escape() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g; s/	/\\t/g'
}

truncate_text() {
  value="$(printf '%s' "$1" | tr '\r\n' '  ')"
  if [ "${#value}" -gt 700 ]; then
    printf '%.700s...[truncated]' "$value"
  else
    printf '%s' "$value"
  fi
}

failure_log_dir() {
  uid="$(id -u 2>/dev/null || printf user)"
  printf '%s/eve-guard-hook-diagnostics-%s' "${TMPDIR:-/tmp}" "$uid"
}

failure_log_path() {
  printf '%s/failures.jsonl' "$(failure_log_dir)"
}

last_failure_path() {
  printf '%s/last-failure.json' "$(failure_log_dir)"
}

write_failure_log() {
  session_id="$1"
  reason="$2"
  payload="$3"
  dir="$(failure_log_dir)"
  old_umask="$(umask)"
  umask 077
  mkdir -p "$dir" 2>/dev/null || { umask "$old_umask"; return; }
  chmod 700 "$dir" 2>/dev/null || true
  tool_name="$(payload_tool_name "$payload")"
  tool_use_id="$(json_get_string_from_text "$payload" tool_use_id)"
  [ -n "$tool_use_id" ] || tool_use_id="$(json_get_string_from_text "$payload" toolUseId)"
  transcript_path="$(payload_transcript_path "$payload")"
  transcript_exists=false
  [ -n "$transcript_path" ] && [ -f "$transcript_path" ] && transcript_exists=true
  has_tool_input=false
  payload_has_field "$payload" 'tool_input|toolInput|input' && has_tool_input=true
  has_tool_response=false
  payload_has_field "$payload" 'tool_response|toolResponse|tool_output|toolOutput' && has_tool_response=true
  payload_keys="$(payload_keys_json "$payload")"
  http_status="$(http_status_from_reason "$reason")"
  [ -z "$http_status" ] && http_status=null
  curl_disabled=false
  [ "$(env_value EVE_HOOK_DISABLE_CURL "")" = "1" ] && curl_disabled=true
  record="$(printf '{"timestamp":"%s","event":"%s","agent":"%s","hook_runtime":"sh","reason":"%s","http_status":%s,"response_preview":"%s","plugin_id":"%s","config_hash":"%s","eve_guard_url":"%s","plugin_root":"%s","session_id":"%s","tool_name":"%s","tool_use_id":"%s","payload_keys":[%s],"has_tool_input":%s,"has_tool_response":%s,"transcript_path":"%s","transcript_path_exists":%s,"failure_mode":"%s","timeout_s":%s,"max_retries":%s,"curl_disabled":%s,"platform":"%s","log_file":"%s","last_failure_file":"%s"}' \
    "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" \
    "$(json_escape "$event_name")" \
    "$(json_escape "$agent")" \
    "$(json_escape "$(truncate_text "$reason")")" \
    "$http_status" \
    "$(json_escape "$(response_preview_from_reason "$reason")")" \
    "$(json_escape "$(env_value EVE_HOOK_PLUGIN_ID "")")" \
    "$(json_escape "$(env_value EVE_HOOK_CONFIG_HASH "")")" \
    "$(json_escape "$(env_value EVE_ORCHESTRATOR_URL "")")" \
    "$(json_escape "$(env_value CLAUDE_PLUGIN_ROOT "")")" \
    "$(json_escape "$session_id")" \
    "$(json_escape "$tool_name")" \
    "$(json_escape "$tool_use_id")" \
    "$payload_keys" \
    "$has_tool_input" \
    "$has_tool_response" \
    "$(json_escape "$transcript_path")" \
    "$transcript_exists" \
    "$(json_escape "$(failure_mode)")" \
    "$(timeout_s)" \
    "$(max_retries)" \
    "$curl_disabled" \
    "$(json_escape "$(uname -a 2>/dev/null)")" \
    "$(json_escape "$(failure_log_path)")" \
    "$(json_escape "$(last_failure_path)")")"
  printf '%s\n' "$record" >> "$(failure_log_path)" 2>/dev/null
  printf '%s' "$record" > "$(last_failure_path)" 2>/dev/null
  chmod 600 "$(failure_log_path)" "$(last_failure_path)" 2>/dev/null || true
  umask "$old_umask"
}

visible_failure_reason() {
  printf 'Eve Guard blocked this %s hook locally because it could not verify the tool call with Eve Guard. Reason: %s. Diagnostics: %s' "$event_name" "$(truncate_text "$1")" "$(last_failure_path)"
}

http_status_from_reason() {
  printf '%s' "$1" | sed -n 's/.*Eve Guard HTTP \([0-9][0-9]*\).*/\1/p'
}

response_preview_from_reason() {
  value="$1"
  case "$value" in
    *"Eve Guard HTTP "*":"*)
      preview="${value#*Eve Guard HTTP }"
      preview="${preview#*:}"
      preview="$(printf '%s' "$preview" | sed 's/^[[:space:]]*//')"
      truncate_text "$preview"
      ;;
    *) printf '' ;;
  esac
}

payload_has_field() {
  printf '%s' "$1" | grep -E "\"($2)\"[[:space:]]*:" >/dev/null 2>&1
}

payload_keys_json() {
  printf '%s' "$1" | awk '
    {
      text = text $0 "\n"
    }
    function escape_json(value) {
      gsub(/\\/, "\\\\", value)
      gsub(/"/, "\\\"", value)
      return value
    }
    function next_non_space(pos,    j, d) {
      for (j = pos; j <= length(text); j++) {
        d = substr(text, j, 1)
        if (d !~ /[[:space:]]/) return d
      }
      return ""
    }
    END {
      depth = 0
      in_string = 0
      escape = 0
      mode = ""
      out = ""
      for (i = 1; i <= length(text); i++) {
        c = substr(text, i, 1)
        if (in_string) {
          if (escape) {
            if (mode == "key") key = key c
            escape = 0
            continue
          }
          if (c == "\\") { escape = 1; continue }
          if (c == "\"") {
            in_string = 0
            if (mode == "key") {
              if (next_non_space(i + 1) == ":") {
                if (out != "") out = out ","
                out = out "\"" escape_json(key) "\""
              }
            }
            mode = ""
            continue
          }
          if (mode == "key") key = key c
          continue
        }
        if (c == "\"") {
          if (depth == 1) {
            in_string = 1
            mode = "key"
            key = ""
          } else {
            in_string = 1
            mode = "skip"
          }
          continue
        }
        if (c == "{" || c == "[") { depth++; continue }
        if (c == "}" || c == "]") { depth--; continue }
      }
      print out
    }
  '
}

json_get_top_value_from_text() {
  printf '%s' "$1" | awk -v wanted="$2" -v kind="$3" '
    {
      text = text $0 "\n"
    }
    function reset_value() {
      expecting_value = 0
      expecting_colon = 0
      last_key = ""
      token = ""
    }
    function append_char(value, c) {
      return value c
    }
    END {
      depth = 0
      in_string = 0
      escape = 0
      mode = ""
      for (i = 1; i <= length(text); i++) {
        c = substr(text, i, 1)
        if (in_string) {
          if (escape) {
            if (mode == "key") {
              key = append_char(key, c)
            } else if (mode == "value") {
              value = append_char(value, c)
            }
            escape = 0
            continue
          }
          if (c == "\\") {
            escape = 1
            continue
          }
          if (c == "\"") {
            in_string = 0
            if (mode == "key") {
              last_key = key
              expecting_colon = 1
            } else if (mode == "value") {
              if (last_key == wanted && kind == "string") {
                print value
                exit
              }
              reset_value()
            }
            mode = ""
            continue
          }
          if (mode == "key") {
            key = append_char(key, c)
          } else if (mode == "value") {
            value = append_char(value, c)
          }
          continue
        }

        if (c == "\"") {
          if (depth == 1 && expecting_value) {
            in_string = 1
            mode = "value"
            value = ""
          } else if (depth == 1 && !expecting_colon) {
            in_string = 1
            mode = "key"
            key = ""
          } else {
            in_string = 1
            mode = "skip"
          }
          continue
        }

        if (c == "{" || c == "[") {
          if (depth == 1 && expecting_value) {
            reset_value()
          }
          depth++
          continue
        }
        if (c == "}" || c == "]") {
          depth--
          reset_value()
          continue
        }
        if (depth == 1 && expecting_colon && c == ":") {
          expecting_colon = 0
          expecting_value = 1
          token = ""
          continue
        }
        if (depth == 1 && expecting_value) {
          if (c ~ /[[:space:]]/) {
            continue
          }
          for (j = i; j <= length(text); j++) {
            d = substr(text, j, 1)
            if (d == "," || d == "}" || d == "]") {
              break
            }
            token = token d
          }
          gsub(/^[[:space:]]+|[[:space:]]+$/, "", token)
          if (last_key == wanted && kind == "scalar") {
            print token
            exit
          }
          reset_value()
          i = j - 1
          continue
        }
        if (depth == 1 && c == ",") {
          reset_value()
        }
      }
    }
  '
}

json_get_string_from_text() {
  json_get_top_value_from_text "$1" "$2" string
}

json_get_account_email_from_text() {
  printf '%s' "$1" | awk '
    {
      text = text $0 "\n"
    }
    function reset_top() {
      top_key = ""
      top_colon = 0
      top_value = 0
    }
    function reset_account_key() {
      account_key = ""
      account_colon = 0
      account_value = 0
    }
    END {
      depth = 0
      in_string = 0
      escape = 0
      mode = ""
      in_account = 0
      account_parent_depth = 0
      for (i = 1; i <= length(text); i++) {
        c = substr(text, i, 1)
        if (in_string) {
          if (escape) {
            if (mode == "top_key") top_key = top_key c
            if (mode == "account_key") account_key = account_key c
            if (mode == "account_value") account_value_text = account_value_text c
            escape = 0
            continue
          }
          if (c == "\\") { escape = 1; continue }
          if (c == "\"") {
            in_string = 0
            if (mode == "top_key") {
              top_colon = 1
            } else if (mode == "account_key") {
              account_colon = 1
            } else if (mode == "account_value") {
              if (account_key == "email") {
                print account_value_text
                exit
              }
              reset_account_key()
            }
            mode = ""
            continue
          }
          if (mode == "top_key") top_key = top_key c
          if (mode == "account_key") account_key = account_key c
          if (mode == "account_value") account_value_text = account_value_text c
          continue
        }

        if (c == "\"") {
          if (in_account && depth == account_parent_depth + 1 && account_value) {
            in_string = 1
            mode = "account_value"
            account_value_text = ""
          } else if (in_account && depth == account_parent_depth + 1 && !account_colon && !account_value) {
            in_string = 1
            mode = "account_key"
            account_key = ""
          } else if (depth == 1 && !top_colon && !top_value) {
            in_string = 1
            mode = "top_key"
            top_key = ""
          } else {
            in_string = 1
            mode = "skip"
          }
          continue
        }

        if (depth == 1 && top_colon && c == ":") {
          top_colon = 0
          top_value = 1
          continue
        }
        if (in_account && depth == account_parent_depth + 1 && account_colon && c == ":") {
          account_colon = 0
          account_value = 1
          continue
        }
        if (c == "{" || c == "[") {
          if (depth == 1 && top_value) {
            if (top_key == "account" && c == "{") {
              in_account = 1
              account_parent_depth = depth
            }
            reset_top()
          } else if (in_account && depth == account_parent_depth + 1 && account_value) {
            reset_account_key()
          }
          depth++
          continue
        }
        if (c == "}" || c == "]") {
          if (in_account && depth == account_parent_depth + 1 && c == "}") {
            in_account = 0
          }
          depth--
          if (depth < 1) reset_top()
          continue
        }
        if (depth == 1 && top_value && c == ",") reset_top()
        if (in_account && depth == account_parent_depth + 1 && account_value && c == ",") reset_account_key()
      }
    }
  '
}

json_get_scalar_from_text() {
  json_get_top_value_from_text "$1" "$2" scalar
}

script_dir() {
  dir="$(dirname "$0" 2>/dev/null)"
  [ -n "$dir" ] && printf '%s' "$dir" || printf '.'
}

# Resolve the baked eve.config.json. Claude Code exports CLAUDE_PLUGIN_ROOT
# and ships the config at its root. Cursor sets no plugin-root env, so fall
# back to script-relative discovery: the launcher is at <root>/hooks/
# cursor-hook.sh and the config at <root>/eve.config.json, i.e.
# $SCRIPT_DIR/../eve.config.json. The same relative path also resolves
# correctly for Claude (CLAUDE_PLUGIN_ROOT/hooks/../eve.config.json), so this
# is a safe superset.
config_path() {
  root="$(env_value CLAUDE_PLUGIN_ROOT "")"
  if [ -n "$root" ] && [ -f "$root/eve.config.json" ]; then
    printf '%s' "$root/eve.config.json"
    return
  fi
  candidate="$(script_dir)/../eve.config.json"
  [ -f "$candidate" ] && printf '%s' "$candidate"
}

load_config_text() {
  path="$(config_path)"
  [ -n "$path" ] && [ -f "$path" ] && tr '\n' ' ' < "$path"
}

set_if_missing() {
  eval "current=\${$1:-}"
  if [ -z "$current" ] && [ -n "$2" ]; then
    export "$1=$2"
  fi
}

apply_config() {
  config_text="$(load_config_text)"
  [ -z "$config_text" ] && return
  set_if_missing EVE_ORCHESTRATOR_URL "$(json_get_string_from_text "$config_text" orchestrator_url)"
  set_if_missing EVE_HOOK_TENANT_ID "$(json_get_string_from_text "$config_text" tenant_id)"
  set_if_missing EVE_HOOK_PLUGIN_ID "$(json_get_string_from_text "$config_text" plugin_id)"
  set_if_missing EVE_HOOK_CONFIG_HASH "$(json_get_string_from_text "$config_text" config_hash)"
  set_if_missing EVE_HOOK_TIMEOUT_S "$(json_get_scalar_from_text "$config_text" timeout_s)"
  set_if_missing EVE_HOOK_FAILURE_MODE "$(json_get_string_from_text "$config_text" failure_mode)"
  set_if_missing EVE_HOOK_MAX_RETRIES "$(json_get_scalar_from_text "$config_text" max_retries)"
  [ "$(json_get_scalar_from_text "$config_text" debug)" = "true" ] && set_if_missing EVE_HOOK_DEBUG "1"
  [ "$(json_get_scalar_from_text "$config_text" disable_curl)" = "true" ] && set_if_missing EVE_HOOK_DISABLE_CURL "1"
}

timeout_s() {
  value="$(env_value EVE_HOOK_TIMEOUT_S 8)"
  case "$value" in ''|*[!0-9]*) value=8 ;; esac
  [ "$value" -lt 1 ] && value=1
  [ "$value" -gt 30 ] && value=30
  printf '%s' "$value"
}

max_retries() {
  value="$(env_value EVE_HOOK_MAX_RETRIES 1)"
  case "$value" in ''|*[!0-9]*) value=1 ;; esac
  [ "$value" -gt 3 ] && value=3
  printf '%s' "$value"
}

failure_mode() {
  mode="$(env_value EVE_HOOK_FAILURE_MODE fail-closed)"
  case "$mode" in fail-open|fail-closed|first-fail-closed) printf '%s' "$mode" ;; *) printf '%s' fail-closed ;; esac
}

# Cursor fires "after"/"post" events once the tool already ran; those need a
# response-phase block shape (replace the MCP output the model sees) instead
# of a pre-tool permission verdict.
is_cursor_post_tool() {
  case "$event_name" in
    afterMCPExecution|postToolUse|afterShellExecution|afterFileEdit|postToolUseFailure) return 0 ;;
    *) return 1 ;;
  esac
}

# Agent-native "no objection" reply for the fail-open path. Cursor pre-tool
# hooks expect an explicit ``permission: allow`` rather than an empty body;
# everything else (Claude, Cursor post-tool) treats ``{}`` as pass-through.
allow_response() {
  if [ "$agent" = "cursor" ] && ! is_cursor_post_tool; then
    printf '{"permission":"allow","continue":true}'
    return
  fi
  printf '{}'
}

deny_response() {
  reason="$(json_escape "$1")"
  if [ "$agent" = "cursor" ]; then
    if is_cursor_post_tool; then
      printf '{"updated_mcp_tool_output":{"isError":true,"content":[{"type":"text","text":"%s"}],"_eve_guard":{"blocked":true,"phase":"response"}},"additional_context":"%s"}' "$reason" "$reason"
      return
    fi
    printf '{"permission":"deny","continue":true,"user_message":"%s","agent_message":"%s"}' "$reason" "$reason"
    return
  fi
  if [ "$event_name" = "PostToolUse" ]; then
    printf '{"decision":"block","reason":"%s","hookSpecificOutput":{"hookEventName":"PostToolUse","additionalContext":"%s","updatedToolOutput":"%s"}}' "$reason" "$reason" "$reason"
    return
  fi
  printf '{"continue":false,"stopReason":"%s","hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"%s"}}' "$reason" "$reason"
}

state_file() {
  key="${1:-global}"
  if command -v shasum >/dev/null 2>&1; then
    hash="$(printf '%s' "$key" | shasum -a 256 | awk '{print substr($1,1,16)}')"
  else
    hash="$(printf '%s' "$key" | cksum | awk '{print $1}')"
  fi
  printf '%s/eve-hook-degraded-%s.flag' "$(env_value EVE_HOOK_STATE_DIR "${TMPDIR:-/tmp}")" "$hash"
}

already_degraded() {
  file="$(state_file "$1")"
  [ -f "$file" ] || return 1
  if find "$file" -mmin +60 -print 2>/dev/null | grep . >/dev/null 2>&1; then
    rm -f "$file"
    return 1
  fi
  return 0
}

mark_degraded() {
  file="$(state_file "$1")"
  mkdir -p "$(dirname "$file")" 2>/dev/null
  printf '%s' "$$" > "$file" 2>/dev/null
}

failure_response() {
  write_failure_log "$1" "$2" "$3"
  mode="$(failure_mode)"
  if [ "$mode" = "fail-open" ]; then allow_response; return; fi
  visible_reason="$(visible_failure_reason "$2")"
  if [ "$mode" = "fail-closed" ]; then deny_response "$visible_reason"; return; fi
  if already_degraded "$1"; then allow_response; return; fi
  mark_degraded "$1"
  deny_response "$visible_reason Following requests in this session will be fail-open."
}

payload_tool_name() {
  name="$(json_get_string_from_text "$1" tool_name)"
  [ -n "$name" ] && { printf '%s' "$name"; return; }
  json_get_string_from_text "$1" toolName
}

payload_transcript_path() {
  path="$(json_get_string_from_text "$1" transcript_path)"
  [ -n "$path" ] && { printf '%s' "$path"; return; }
  json_get_string_from_text "$1" transcriptPath
}

calling_guid() {
  payload="$(printf '%s' "$1" | tr '\n' ' ')"
  tool_name="$(payload_tool_name "$payload")"
  printf '%s' "$tool_name" | sed -n 's/^mcp__\([0-9a-fA-F-][0-9a-fA-F-]*\)__.*/\1/p'
}

namespace_tools_json() {
  transcript_path="$1"
  guid="$2"
  [ -n "$transcript_path" ] || return
  [ -n "$guid" ] || return
  [ -f "$transcript_path" ] || return

  tail -n 800 "$transcript_path" | awk -v prefix="mcp__${guid}__" '
    function escape_json(value) {
      gsub(/\\/, "\\\\", value)
      gsub(/"/, "\\\"", value)
      return value
    }
    {
      lines[NR] = $0
    }
    END {
      for (i = NR; i >= 1; i--) {
        line = lines[i]
        has_delta_type = line ~ /"type"[[:space:]]*:[[:space:]]*"deferred_tools_delta"/
        has_delta_field = line ~ /"deferred_tools_delta"[[:space:]]*:/
        if (!has_delta_type && !has_delta_field) {
          continue
        }

        found = 0
        while (match(line, prefix "[A-Za-z0-9_.:-]+")) {
          tool = substr(line, RSTART + length(prefix), RLENGTH - length(prefix))
          line = substr(line, RSTART + RLENGTH)
          if (!(tool in seen)) {
            if (out != "") {
              out = out ","
            }
            out = out "\"" escape_json(tool) "\""
            seen[tool] = 1
            found = 1
          }
        }

        if (found) {
          print out
          exit
        }
      }
    }
  '
}

envelope_email() {
  transcript_path="$1"
  [ -n "$transcript_path" ] || return
  dir="$(dirname "$transcript_path")"
  i=0
  while [ "$i" -lt 8 ] && [ -n "$dir" ] && [ "$dir" != "/" ]; do
    base="$(basename "$dir")"
    candidate="${dir}.json"
    if [ "${base#local_}" != "$base" ] && [ -f "$candidate" ]; then
      text="$(tr '\n' ' ' < "$candidate")"
      email="$(json_get_string_from_text "$text" emailAddress)"
      [ -n "$email" ] && { printf '%s' "$email"; return; }
      email="$(json_get_account_email_from_text "$text")"
      [ -n "$email" ] && { printf '%s' "$email"; return; }
      email="$(json_get_string_from_text "$text" email)"
      [ -n "$email" ] && { printf '%s' "$email"; return; }
    fi
    parent="$(dirname "$dir")"
    [ "$parent" = "$dir" ] && break
    dir="$parent"
    i=$((i + 1))
  done
}

user_email() {
  payload_email="$(json_get_string_from_text "$1" user_email)"
  [ -n "$payload_email" ] && { printf '%s' "$payload_email"; return; }
  for name in CURSOR_USER_EMAIL CLAUDE_CODE_USER_EMAIL CLAUDE_USER_EMAIL USER_EMAIL; do
    value="$(env_value "$name" "")"
    [ -n "$value" ] && { printf '%s' "$value"; return; }
  done
  envelope_email "$(payload_transcript_path "$1")"
}

append_payload_fields() {
  raw="$1"
  extras=""
  email="$(user_email "$raw")"
  guid="$(calling_guid "$raw")"
  [ -n "$email" ] && extras="$extras,\"user_email\":\"$(json_escape "$email")\""
  if [ -n "$guid" ]; then
    extras="$extras,\"eve_mcp_directory_uuid\":\"$(json_escape "$guid")\""
    tools="$(namespace_tools_json "$(payload_transcript_path "$raw")" "$guid")"
    [ -n "$tools" ] && extras="$extras,\"eve_mcp_namespace_tools\":[$tools]"
  fi
  [ -z "$extras" ] && { printf '%s' "$raw"; return; }
  trimmed="$(printf '%s' "$raw" | sed 's/[[:space:]]*$//')"
  case "$trimmed" in
    *}) printf '%s%s}' "${trimmed%?}" "$extras" ;;
    *) printf '%s' "$raw" ;;
  esac
}

is_transient() {
  printf '%s' "$1" | grep -E 'EAI_AGAIN|EAI_NODATA|EAI_NONAME|ECONNRESET|ECONNREFUSED|ETIMEDOUT|ENOTFOUND|socket hang up|timeout after [0-9]+ms|curl exit (6|7|18|28|35|52|55|56|92)\b' >/dev/null 2>&1
}

dispatch_once() {
  [ "$(env_value EVE_HOOK_DISABLE_CURL "")" = "1" ] && { printf '%s' "ERR curl disabled"; return 1; }
  command -v curl >/dev/null 2>&1 || { printf '%s' "ERR curl not found"; return 1; }
  base="$(env_value EVE_ORCHESTRATOR_URL "")"
  [ -n "$base" ] || { printf '%s' "ERR EVE_ORCHESTRATOR_URL not set"; return 1; }

  endpoint="$(printf '%s/hooks/%s/%s' "$(printf '%s' "$base" | sed 's:/*$::')" "$agent" "$event_name")"
  body_file="$(mktemp "${TMPDIR:-/tmp}/eve-hook-body.XXXXXX")"
  err_file="$(mktemp "${TMPDIR:-/tmp}/eve-hook-err.XXXXXX")"
  printf '%s' "$1" > "$body_file"

  plugin_id="$(env_value EVE_HOOK_PLUGIN_ID "")"
  if printf '%s' "$plugin_id" | grep -E '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$' >/dev/null 2>&1; then
    response="$(curl --silent --show-error --max-time "$(timeout_s)" -X POST -H "Content-Type: application/json; charset=utf-8" -H "X-Eve-Hook-Plugin-Id: $plugin_id" --data-binary "@$body_file" -w '\n__EVE_HOOK_STATUS__:%{http_code}' "$endpoint" 2>"$err_file")"
  else
    response="$(curl --silent --show-error --max-time "$(timeout_s)" -X POST -H "Content-Type: application/json; charset=utf-8" --data-binary "@$body_file" -w '\n__EVE_HOOK_STATUS__:%{http_code}' "$endpoint" 2>"$err_file")"
  fi

  code=$?
  rm -f "$body_file"
  status="$(printf '%s' "$response" | sed -n 's/^__EVE_HOOK_STATUS__://p' | tail -1)"
  body="$(printf '%s' "$response" | sed '/^__EVE_HOOK_STATUS__:/d')"

  if [ "$code" -ne 0 ]; then
    stderr="$(sed 's/[[:space:]]*$//' "$err_file" 2>/dev/null)"
    rm -f "$err_file"
    printf '%s' "ERR curl exit $code: ${stderr:-no stderr}"
    return 1
  fi
  rm -f "$err_file"
  case "$status" in
    2*) printf '%s' "$body"; return 0 ;;
    *) printf '%s' "ERR Eve Guard HTTP ${status:-0}: $(truncate_text "$body")"; return 1 ;;
  esac
}

dispatch_with_retry() {
  max="$(max_retries)"
  attempt=0
  while [ "$attempt" -le "$max" ]; do
    result="$(dispatch_once "$1")" && { printf '%s' "$result"; return 0; }
    reason="${result#ERR }"
    if ! is_transient "$reason" || [ "$attempt" -eq "$max" ]; then
      printf '%s' "$reason"
      return 1
    fi
    sleep "$retry_backoff_s"
    attempt=$((attempt + 1))
  done
}

main() {
  apply_config
  raw_payload="$(cat)"
  session_id="$(json_get_string_from_text "$raw_payload" session_id)"
  payload="$(append_payload_fields "$raw_payload")"
  result="$(dispatch_with_retry "$payload")" && { printf '%s' "$result"; exit 0; }
  debug_log "dispatch failed: $result"
  failure_response "$session_id" "$result" "$payload"
  exit 0
}

main
