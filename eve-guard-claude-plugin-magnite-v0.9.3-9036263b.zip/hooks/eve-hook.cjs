#!/usr/bin/env node
// =============================================================================
// Eve Agent Hook — pure-Node, cross-platform.
// =============================================================================
//
// Read the raw payload on stdin, optionally augment it with Cowork
// resolution signals + identity, POST it to
// ``$EVE_ORCHESTRATOR_URL/hooks/<agent>/<event>``, return the
// orchestrator's verdict on stdout in Anthropic ``hookSpecificOutput``
// shape.
//
// Why pure Node:
//   * Claude Code itself is a Node CLI, so ``node`` is guaranteed on
//     PATH wherever the hook can run (host loop and Cowork sandbox).
//     Anything else (``bash``, ``curl``, ``python3``) is OS-dependent.
//   * One process per hook call instead of bash + N node subprocesses
//     for the extraction stages → meaningfully lower latency under the
//     Cowork PreToolUse timeout budget (10 s).
//   * Same source file runs on macOS, Linux, and Windows.
//
// What this hook does, in order:
//   1. Inject ``payload.user_email`` from ``CLAUDE_CODE_USER_EMAIL`` /
//      ``USER_EMAIL`` env, or — failing that — from the Cowork session
//      envelope sibling-of ``transcript_path``.
//   2. For Cowork-namespaced ``mcp__<guid>__<tool>`` calls, extract the
//      GUID and the most-recent ``deferred_tools_delta`` fingerprint so
//      ``ResourceFetcher.resolve_resource_ids`` can map the opaque
//      session GUID to a real ``public.resources`` row.
//   3. POST to the orchestrator. Convert its allow/deny verdict into
//      Anthropic's hookSpecificOutput JSON.
//
// Filtering built-in tool calls (Bash, Read, ToolSearch, …) is the
// responsibility of the plugin's ``hooks.json`` matcher
// (``"matcher": "mcp__.*"``) — Cowork won't even spawn this process
// for non-MCP tool names, which is strictly cheaper than gating
// in-process. ``isMcpToolName`` is kept as an exported helper for
// callers that want to filter at a different layer.
//
// Failure-mode policy is configurable via ``EVE_HOOK_FAILURE_MODE``:
//   * ``first-fail-closed`` (default) — first failure in a session is
//     surfaced as a deny so the user notices something is wrong; every
//     subsequent failure in the same session degrades to fail-open so
//     the user isn't stuck.
//   * ``fail-closed``  — every failure is a deny.
//   * ``fail-open``    — every failure is an allow (legacy behaviour).
//
// "Failure" = missing ``EVE_ORCHESTRATOR_URL``, malformed URL,
// connect/dispatch error, timeout, or a non-2xx response. A successful
// orchestrator deny verdict is *not* a failure — it's passed through
// verbatim.
//
// Optional env:
//   * ``EVE_HOOK_TIMEOUT_S``    (default ``8``)
//   * ``EVE_HOOK_FAILURE_MODE`` (default ``first-fail-closed``)
//   * ``EVE_HOOK_DEBUG``        (``1`` to log to stderr)
//   * ``EVE_HOOK_STATE_DIR``    (default ``os.tmpdir()``; first-fail
//                                state files live here)
// =============================================================================

'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const http = require('node:http');
const https = require('node:https');
const { spawn } = require('node:child_process');
const { URL } = require('node:url');

const UUID_RE =
  /^([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})__/;
const MCP_PREFIX = 'mcp__';
const TAIL_BYTES = 256 * 1024;
// Per-attempt HTTP timeout (DNS + connect + request + response). Kept
// well under Cowork's plugin-level hook timeout (10s in hooks.json) so
// we can afford one retry on top of the first attempt without busting
// the budget: 4 + 0.15 + 4 = ~8.15s worst case.
const DEFAULT_TIMEOUT_S = 4;
// One retry on transient network errors only (EAI_AGAIN / ECONNRESET /
// ECONNREFUSED / ETIMEDOUT / "socket hang up"). HTTP 4xx/5xx are NOT
// retried — those are real orchestrator answers. Cowork's sandbox
// commonly hits a cold-resolver EAI_AGAIN on the first lookup of a
// freshly-allowlisted host; the retry warms DNS and avoids the
// fail-closed deny from firing on infra hiccups.
const DEFAULT_MAX_RETRIES = 1;
const RETRY_BACKOFF_MS = 150;
// Transient-error sniff — these strings come from Node's net/dns
// error messages or our own ``timeout after Xms`` reason and indicate
// the error was network-layer, not application-layer.
const _TRANSIENT_ERROR_PATTERNS = [
  /EAI_AGAIN/i,
  /EAI_NODATA/i,
  /EAI_NONAME/i,
  /ECONNRESET/i,
  /ECONNREFUSED/i,
  /ETIMEDOUT/i,
  /ENOTFOUND/i,
  /socket hang up/i,
  /timeout after \d+ms/i,
  // curl exit codes that map to retryable network-layer errors:
  //   6  couldn't resolve host    (~ EAI_AGAIN / ENOTFOUND)
  //   7  failed to connect        (~ ECONNREFUSED)
  //   18 partial transfer / interrupted
  //   28 operation timeout        (~ ETIMEDOUT)
  //   35 SSL connect error        (transient on cold TLS / proxy warm-up)
  //   52 empty reply from server  (~ socket hang up)
  //   55 failed sending data
  //   56 failure receiving network data (~ ECONNRESET)
  //   92 HTTP/2 stream not closed cleanly
  // 4xx/5xx orchestrator responses are NOT retried — those are real
  // application answers and surface as ``orchestrator HTTP <status>``,
  // which intentionally doesn't match this list.
  /curl exit (?:6|7|18|28|35|52|55|56|92)\b/i,
];
const FAIL_OPEN_RESPONSE = '{}';
const DEFAULT_FAILURE_MODE = 'first-fail-closed';
const VALID_FAILURE_MODES = new Set([
  'fail-open',
  'fail-closed',
  'first-fail-closed',
]);
const STATE_FILE_TTL_MS = 60 * 60 * 1000;
const EMAIL_ENV_VARS = [
  'CLAUDE_CODE_USER_EMAIL',
  'CLAUDE_USER_EMAIL',
  'USER_EMAIL',
];

// Mapping from baked-config keys (eve.config.json, snake_case) to the
// EVE_* env vars the hook actually reads. Stringifier coerces every
// value to the string shape the env-parsing helpers above expect.
const BAKED_CONFIG_ENV_MAP = {
  orchestrator_url: { env: 'EVE_ORCHESTRATOR_URL', toEnv: (v) => String(v) },
  tenant_id:        { env: 'EVE_HOOK_TENANT_ID',   toEnv: (v) => String(v) },
  plugin_id:        { env: 'EVE_HOOK_PLUGIN_ID',   toEnv: (v) => String(v) },
  config_hash:      { env: 'EVE_HOOK_CONFIG_HASH', toEnv: (v) => String(v) },
  timeout_s:        { env: 'EVE_HOOK_TIMEOUT_S',   toEnv: (v) => String(v) },
  failure_mode:     { env: 'EVE_HOOK_FAILURE_MODE',toEnv: (v) => String(v) },
  max_retries:      { env: 'EVE_HOOK_MAX_RETRIES', toEnv: (v) => String(v) },
  debug:            { env: 'EVE_HOOK_DEBUG',       toEnv: (v) => (v ? '1' : '0') },
  disable_curl:     { env: 'EVE_HOOK_DISABLE_CURL',toEnv: (v) => (v ? '1' : '0') },
};

// ---------------------------------------------------------------------------
// Baked runtime config (eve.config.json next to plugin.json)
//
// Claude Code's plugin hook schema does NOT support an ``env`` block on
// command hooks, so we can't bake EVE_* env vars into hooks.json. The
// build pipeline ships a sibling ``eve.config.json`` at the plugin
// root instead; we read it here at startup and merge it into
// ``process.env`` for any key the user hasn't already set. Real env
// vars win so users can override at runtime for debugging without
// rebuilding the zip.
// ---------------------------------------------------------------------------

function loadBakedConfig() {
  const root = process.env.CLAUDE_PLUGIN_ROOT;
  if (!root || typeof root !== 'string') return {};
  const file = path.join(root, 'eve.config.json');
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (err) {
    if (err && err.code !== 'ENOENT') {
      logDebug(`eve.config.json read failed: ${err.message}`);
    }
    return {};
  }
  try {
    const parsed = JSON.parse(text);
    return isPlainObject(parsed) ? parsed : {};
  } catch (err) {
    process.stderr.write(
      `[eve-hook] warning: malformed eve.config.json at ${file}: ${err && err.message}\n`
    );
    return {};
  }
}

function applyBakedConfigToEnv(baked) {
  if (!isPlainObject(baked)) return;
  for (const [key, mapping] of Object.entries(BAKED_CONFIG_ENV_MAP)) {
    if (!Object.prototype.hasOwnProperty.call(baked, key)) continue;
    if (process.env[mapping.env] !== undefined && process.env[mapping.env] !== '') continue;
    const value = baked[key];
    if (value === null || value === undefined) continue;
    process.env[mapping.env] = mapping.toEnv(value);
  }
}

// ---------------------------------------------------------------------------
// Small utilities
// ---------------------------------------------------------------------------

function debugEnabled() {
  return process.env.EVE_HOOK_DEBUG === '1';
}

function logDebug(msg) {
  if (debugEnabled()) process.stderr.write(`[eve-hook] ${msg}\n`);
}

function parseMaxRetries() {
  const raw = process.env.EVE_HOOK_MAX_RETRIES;
  if (raw === undefined || raw === '') return DEFAULT_MAX_RETRIES;
  const n = Number.parseInt(raw, 10);
  if (!Number.isFinite(n) || n < 0) return DEFAULT_MAX_RETRIES;
  // Hard cap at 3 so a bad env var can't blow the Cowork timeout budget.
  return Math.min(n, 3);
}

function isTransientReason(reason) {
  if (!reason) return false;
  return _TRANSIENT_ERROR_PATTERNS.some((re) => re.test(reason));
}

function parseTimeoutMs() {
  const raw = process.env.EVE_HOOK_TIMEOUT_S;
  const parsed = raw ? parseFloat(raw) : DEFAULT_TIMEOUT_S;
  if (!Number.isFinite(parsed) || parsed <= 0) return DEFAULT_TIMEOUT_S * 1000;
  return Math.round(parsed * 1000);
}

function parseFailureMode() {
  const raw = (process.env.EVE_HOOK_FAILURE_MODE || '').trim().toLowerCase();
  if (!raw) return DEFAULT_FAILURE_MODE;
  if (!VALID_FAILURE_MODES.has(raw)) {
    logDebug(`unknown EVE_HOOK_FAILURE_MODE="${raw}"; using default`);
    return DEFAULT_FAILURE_MODE;
  }
  return raw;
}

function safeParse(text) {
  if (typeof text !== 'string') return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function isMcpToolName(name) {
  return typeof name === 'string' && name.startsWith(MCP_PREFIX);
}

// Cache curl-availability detection across calls in the same process.
// First failed dispatch sets the flag; subsequent calls in the same
// process skip the curl attempt entirely.
let _curlAvailable = null; // null = unknown, true/false once decided

function curlDisabledByEnv() {
  return process.env.EVE_HOOK_DISABLE_CURL === '1';
}

function markCurlMissing() {
  _curlAvailable = false;
}

// ---------------------------------------------------------------------------
// Anthropic hookSpecificOutput response shapes.
//
// The shape Claude Code expects on stdout differs by event:
//
// * ``PreToolUse``  — ``hookSpecificOutput.permissionDecision`` controls
//   whether the tool call is executed at all. ``deny`` blocks the call,
//   and ``continue: false`` + ``stopReason`` halt the agent loop on top
//   of that.
// * ``PostToolUse`` — the tool already ran, so there's no permission to
//   decide. Claude Code's CLI **silently ignores ``continue: false`` on
//   PostToolUse hooks** (see anthropics/claude-code#29991), so emitting
//   it here gives a false impression of halting the loop and makes the
//   fail-closed contract harder to reason about. The single field that
//   actually feeds back to the model is the documented ``decision:
//   "block"`` + ``reason`` shape; we mirror the message into
//   ``hookSpecificOutput.additionalContext`` so it shows up in the
//   transcript regardless of which key the host version honors.
//
// Either shape is interpreted as "fail-closed" by the host; ``allowResponse``
// is the same empty body for both events.
// ---------------------------------------------------------------------------

const POST_TOOL_USE_EVENT = 'PostToolUse';

function denyResponse(reason, event) {
  const eventName = typeof event === 'string' && event ? event : 'PreToolUse';
  if (eventName === POST_TOOL_USE_EVENT) {
    return JSON.stringify({
      decision: 'block',
      reason,
      hookSpecificOutput: {
        hookEventName: POST_TOOL_USE_EVENT,
        additionalContext: reason,
      },
    });
  }
  return JSON.stringify({
    continue: false,
    stopReason: reason,
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: 'deny',
      permissionDecisionReason: reason,
    },
  });
}

function allowResponse() {
  return FAIL_OPEN_RESPONSE;
}

// ---------------------------------------------------------------------------
// First-fail-closed state file. Keyed by ``session_id`` so a single
// degraded outage doesn't fail-close every concurrent session, and so
// a fresh session always gets one (1) loud surface of the failure.
// Stale entries are GC'd by TTL on every read.
// ---------------------------------------------------------------------------

function stateDir() {
  return process.env.EVE_HOOK_STATE_DIR || os.tmpdir();
}

function stateFilePath(sessionId) {
  const key = sessionId && typeof sessionId === 'string' ? sessionId : 'global';
  const safe = crypto
    .createHash('sha256')
    .update(key)
    .digest('hex')
    .slice(0, 16);
  return path.join(stateDir(), `eve-hook-degraded-${safe}.flag`);
}

function alreadyDegraded(sessionId) {
  const file = stateFilePath(sessionId);
  try {
    const stat = fs.statSync(file);
    if (Date.now() - stat.mtimeMs > STATE_FILE_TTL_MS) {
      try {
        fs.unlinkSync(file);
      } catch {
        /* best-effort */
      }
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

function markDegraded(sessionId) {
  const file = stateFilePath(sessionId);
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, String(Date.now()), { mode: 0o600 });
  } catch (err) {
    logDebug(`state write failed: ${err && err.message}`);
  }
}

// ---------------------------------------------------------------------------
// resolveFailureResponse — central decision: given a failure mode and
// the current session's prior state, produce the response body to
// write to stdout. Returns ``{ body, isDeny }``.
// ---------------------------------------------------------------------------
function resolveFailureResponse(mode, sessionId, reason, event) {
  if (mode === 'fail-open') {
    return { body: allowResponse(), isDeny: false };
  }
  if (mode === 'fail-closed') {
    return { body: denyResponse(reason, event), isDeny: true };
  }
  if (alreadyDegraded(sessionId)) {
    return { body: allowResponse(), isDeny: false };
  }
  markDegraded(sessionId);
  const userMsg =
    `Error verifying with security policy: ${reason}. ` +
    `Following requests in this session will be fail-open.`;
  return { body: denyResponse(userMsg, event), isDeny: true };
}

// ---------------------------------------------------------------------------
// extractCallingGuid — pulls the GUID from a Cowork-style
// ``mcp__<guid>__<tool>`` tool_name. Returns ``""`` otherwise.
// ---------------------------------------------------------------------------
function extractCallingGuid(payload) {
  if (!isPlainObject(payload)) return '';
  const toolName = payload.tool_name || payload.toolName || '';
  if (!isMcpToolName(toolName)) return '';
  const m = toolName.slice(MCP_PREFIX.length).match(UUID_RE);
  return m ? m[1] : '';
}

// ---------------------------------------------------------------------------
// readTranscriptTail — read at most the trailing ``TAIL_BYTES`` of the
// transcript so giant Cowork sessions don't balloon hook latency.
// ---------------------------------------------------------------------------
function readTranscriptTail(transcriptPath) {
  let fd = -1;
  try {
    fd = fs.openSync(transcriptPath, 'r');
    const stat = fs.fstatSync(fd);
    const len = Math.min(stat.size, TAIL_BYTES);
    if (len <= 0) return { text: '', truncated: false };
    const buf = Buffer.alloc(len);
    const offset = Math.max(0, stat.size - len);
    fs.readSync(fd, buf, 0, len, offset);
    return { text: buf.toString('utf8'), truncated: offset > 0 };
  } catch {
    return { text: '', truncated: false };
  } finally {
    if (fd !== -1) {
      try {
        fs.closeSync(fd);
      } catch {
        /* best-effort */
      }
    }
  }
}

// ---------------------------------------------------------------------------
// deltaToolNames — yield every tool name found inside a single
// transcript event's ``deferred_tools_delta`` slot.
// ---------------------------------------------------------------------------
function* deltaToolNames(ev) {
  if (!isPlainObject(ev)) return;
  const candidates = [];
  const att = ev.attachment;
  if (isPlainObject(att) && att.type === 'deferred_tools_delta') {
    candidates.push(att);
  }
  const nestedAtt = isPlainObject(ev.message) && ev.message.attachment;
  if (isPlainObject(nestedAtt) && nestedAtt.type === 'deferred_tools_delta') {
    candidates.push(nestedAtt);
  }
  if (isPlainObject(ev.deferred_tools_delta)) {
    candidates.push(ev.deferred_tools_delta);
  }
  for (const delta of candidates) {
    for (const field of ['addedNames', 'tools']) {
      const arr = delta[field];
      if (!Array.isArray(arr)) continue;
      for (const entry of arr) {
        if (typeof entry === 'string') {
          yield entry;
        } else if (isPlainObject(entry) && typeof entry.name === 'string') {
          yield entry.name;
        }
      }
    }
  }
}

// ---------------------------------------------------------------------------
// extractNamespaceTools — scan the transcript for the most recent
// ``deferred_tools_delta`` whose tools share the calling GUID's
// namespace, strip the ``mcp__<guid>__`` prefix, dedupe, return array.
// ---------------------------------------------------------------------------
function extractNamespaceTools(transcriptPath, guid) {
  if (
    typeof transcriptPath !== 'string' ||
    !transcriptPath ||
    typeof guid !== 'string' ||
    !guid
  ) {
    return [];
  }
  const { text, truncated } = readTranscriptTail(transcriptPath);
  if (!text) return [];

  let lines = text.split('\n');
  if (truncated && lines.length > 1) lines = lines.slice(1);

  const prefix = `${MCP_PREFIX}${guid}__`;
  let namespaced = [];
  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i].trim();
    if (!line) continue;
    let ev;
    try {
      ev = JSON.parse(line);
    } catch {
      continue;
    }
    const found = [];
    for (const n of deltaToolNames(ev)) {
      if (typeof n === 'string' && n.startsWith(prefix)) found.push(n);
    }
    if (found.length) {
      namespaced = found;
      break;
    }
  }

  const seen = new Set();
  const unique = [];
  for (const full of namespaced) {
    const bare = full.slice(prefix.length);
    if (!bare || seen.has(bare)) continue;
    seen.add(bare);
    unique.push(bare);
  }
  return unique;
}

// ---------------------------------------------------------------------------
// resolveUserEmail — try env vars (most authoritative, set by the
// agent/IDE), then walk up from ``transcript_path`` to read the
// Cowork session envelope's ``emailAddress``/``account.email`` if
// present. Returns ``""`` if nothing is found.
// ---------------------------------------------------------------------------
function resolveUserEmail(payload) {
  if (isPlainObject(payload) && typeof payload.user_email === 'string') {
    const explicit = payload.user_email.trim();
    if (explicit) return explicit;
  }

  for (const key of EMAIL_ENV_VARS) {
    const v = process.env[key];
    if (typeof v === 'string' && v.trim()) return v.trim();
  }

  const transcriptPath =
    isPlainObject(payload) && typeof payload.transcript_path === 'string'
      ? payload.transcript_path
      : '';
  if (!transcriptPath) return '';

  // Cowork layout:
  //   <bundle>/local_<sid>.json                 ← envelope (siblings)
  //   <bundle>/local_<sid>/.claude/projects/.../<uuid>.jsonl   ← transcript
  // Walk up parent dirs looking for ``local_*.json`` siblings.
  try {
    let dir = path.dirname(transcriptPath);
    for (let depth = 0; depth < 8 && dir && dir !== path.dirname(dir); depth++) {
      const candidate = `${dir}.json`;
      if (
        path.basename(dir).startsWith('local_') &&
        fs.existsSync(candidate)
      ) {
        const text = fs.readFileSync(candidate, 'utf8');
        const obj = safeParse(text);
        if (isPlainObject(obj)) {
          if (typeof obj.emailAddress === 'string' && obj.emailAddress.trim()) {
            return obj.emailAddress.trim();
          }
          const acct = isPlainObject(obj.account) ? obj.account : null;
          if (acct && typeof acct.email === 'string' && acct.email.trim()) {
            return acct.email.trim();
          }
        }
      }
      dir = path.dirname(dir);
    }
  } catch (err) {
    logDebug(`envelope email lookup failed: ${err && err.message}`);
  }
  return '';
}

// ---------------------------------------------------------------------------
// augmentPayload — single pass: parse, inject email + resolver signals,
// re-serialize. Returns the raw input unchanged on any parse failure
// (the orchestrator already tolerates an opaque pass-through body).
// ---------------------------------------------------------------------------
function augmentPayload(rawPayload) {
  const payload = safeParse(rawPayload);
  if (!isPlainObject(payload)) return rawPayload;

  const email = resolveUserEmail(payload);
  if (email && !payload.user_email) payload.user_email = email;

  const guid = extractCallingGuid(payload);
  if (guid) {
    const transcriptPath =
      typeof payload.transcript_path === 'string'
        ? payload.transcript_path
        : typeof payload.transcriptPath === 'string'
        ? payload.transcriptPath
        : '';
    const tools = extractNamespaceTools(transcriptPath, guid);
    payload.eve_mcp_directory_uuid = guid;
    if (tools.length > 0) payload.eve_mcp_namespace_tools = tools;
    logDebug(
      `augment: guid=${guid} tools=${tools.length} email=${email || '<none>'}`
    );
  } else {
    logDebug(`augment: non-cowork tool email=${email || '<none>'}`);
  }

  try {
    return JSON.stringify(payload);
  } catch {
    return rawPayload;
  }
}

// Back-compat: legacy entry point name used by tests.
function injectResolutionSignals(rawPayload) {
  return augmentPayload(rawPayload);
}

// ---------------------------------------------------------------------------
// readStdin — read entire stdin to a string. Returns ``""`` on error.
// ---------------------------------------------------------------------------
function readStdin() {
  return new Promise((resolve) => {
    const chunks = [];
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
    process.stdin.on('data', (c) => chunks.push(c));
    process.stdin.on('end', () =>
      finish(Buffer.concat(chunks).toString('utf8'))
    );
    process.stdin.on('error', (err) => {
      logDebug(`stdin read failed: ${err && err.message}`);
      finish(Buffer.concat(chunks).toString('utf8'));
    });
  });
}

// ---------------------------------------------------------------------------
// dispatchHook — POST the payload to the orchestrator.
//
// Why we cascade through curl first, node:https second:
//
// In Cowork's sandbox, outbound traffic is forced through a local
// HTTP/HTTPS proxy at ``localhost:3128``. The sandbox has no real DNS
// resolver — ``getaddrinfo`` returns ``EAI_AGAIN`` for every host —
// so ``node:https`` (and built-in ``fetch()``) fail instantly because
// Node, by default, ignores ``HTTP_PROXY`` / ``HTTPS_PROXY`` env vars.
// ``curl`` honors those env vars natively, so it works for both
// proxy-required (Cowork) and proxy-free (laptop / CI) environments.
// We measured curl as the fastest working transport in Cowork
// (~720ms vs ~800ms for the other working modes) so it's also our
// happy-path winner.
//
// curl is universally available on the platforms we care about
// (macOS, modern Linux, Windows 10+). The ``node:https`` fallback
// keeps us covered if a user lands on a stripped-down system without
// curl AND doesn't need a proxy. Setting ``EVE_HOOK_DISABLE_CURL=1``
// forces the fallback path (used by tests; also a user-facing escape
// hatch).
//
// Resolves with ``{ ok, body, reason }`` so ``main`` can apply the
// failure policy uniformly. Never writes to stdout itself.
// ---------------------------------------------------------------------------
function dispatchHook(agent, event, payload, options) {
  const opts = options || {};
  const orchestratorUrl = opts.orchestratorUrl || '';
  const timeoutMs = opts.timeoutMs || DEFAULT_TIMEOUT_S * 1000;

  if (!orchestratorUrl) {
    return Promise.resolve({
      ok: false,
      body: '',
      reason: 'EVE_ORCHESTRATOR_URL not set',
    });
  }

  let target;
  try {
    target = new URL(
      `${orchestratorUrl.replace(/\/+$/, '')}/hooks/` +
        `${encodeURIComponent(agent)}/${encodeURIComponent(event)}`
    );
  } catch (err) {
    return Promise.resolve({
      ok: false,
      body: '',
      reason: `bad EVE_ORCHESTRATOR_URL: ${err && err.message}`,
    });
  }

  // Custom request headers — start with Content-Type and conditionally
  // add the plugin id so the orchestrator can stamp each interaction
  // with the originating plugin row. Missing env = no header (older
  // zips built before this feature simply don't carry the id).
  const headers = buildRequestHeaders(opts);

  // Cascade: curl → node:https. Force-skip curl when the env says so
  // or when a previous call in this process already established that
  // curl isn't on PATH.
  if (curlDisabledByEnv() || _curlAvailable === false) {
    return dispatchHookViaNodeHttps(target, payload, timeoutMs, headers);
  }
  return dispatchHookViaCurl(target, payload, timeoutMs, headers).then((curlResult) => {
    if (curlResult.curl_missing !== true) return curlResult;
    markCurlMissing();
    logDebug('curl unavailable; falling back to node:https');
    return dispatchHookViaNodeHttps(target, payload, timeoutMs, headers);
  });
}

// UUIDv1-v5 check. Tolerant of whitespace; rejects anything that doesn't
// match so a malformed env var doesn't get forwarded as a junk header.
const _UUID_HEADER_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function buildRequestHeaders(opts) {
  const headers = { 'Content-Type': 'application/json' };
  const rawPluginId = (opts && opts.pluginId) || process.env.EVE_HOOK_PLUGIN_ID || '';
  const pluginId = typeof rawPluginId === 'string' ? rawPluginId.trim() : '';
  if (pluginId && _UUID_HEADER_RE.test(pluginId)) {
    headers['X-Eve-Hook-Plugin-Id'] = pluginId;
  } else if (pluginId) {
    logDebug(`ignoring malformed EVE_HOOK_PLUGIN_ID="${pluginId}"`);
  }
  return headers;
}

// ---------------------------------------------------------------------------
// dispatchHookViaCurl — spawn ``curl`` to POST the payload. Honors
// ``HTTP_PROXY`` / ``HTTPS_PROXY`` / ``NO_PROXY`` env vars natively
// (the entire reason this transport exists — see ``dispatchHook``).
//
// Returns the same ``{ ok, body, reason }`` shape as the node:https
// path, plus an internal ``curl_missing: true`` flag when curl isn't
// on PATH so the caller can cascade.
// ---------------------------------------------------------------------------
function dispatchHookViaCurl(target, payload, timeoutMs, headers) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };

    const statusMarker = '__EVE_HOOK_STATUS__';
    // ``--data-binary @-`` reads body from stdin (no argv-length limits).
    // ``-w`` appends ``\n<marker>:<status>`` after the response body so
    // we can parse the status code from stdout without parsing headers.
    // ``--max-time`` is in seconds — ceil to avoid 0 on sub-second budgets.
    const maxTimeSec = Math.max(1, Math.ceil(timeoutMs / 1000));
    const args = [
      '--silent',
      '--show-error',
      '--max-time', String(maxTimeSec),
      '-X', 'POST',
    ];
    for (const [name, value] of Object.entries(headers || {})) {
      args.push('-H', `${name}: ${value}`);
    }
    args.push(
      '--data-binary', '@-',
      '-w', `\n${statusMarker}:%{http_code}`,
      target.href,
    );

    let child;
    try {
      child = spawn('curl', args, { stdio: ['pipe', 'pipe', 'pipe'] });
    } catch (err) {
      finish({
        ok: false,
        body: '',
        reason: `curl spawn threw: ${err && err.message}`,
        curl_missing: err && err.code === 'ENOENT',
      });
      return;
    }

    const stdoutChunks = [];
    const stderrChunks = [];
    let killedByTimeout = false;

    const timer = setTimeout(() => {
      killedByTimeout = true;
      try { child.kill('SIGKILL'); } catch (_) { /* best-effort */ }
    }, timeoutMs + 500); // small grace over curl's own --max-time

    child.stdout.on('data', (c) => stdoutChunks.push(c));
    child.stderr.on('data', (c) => stderrChunks.push(c));

    child.on('error', (err) => {
      clearTimeout(timer);
      finish({
        ok: false,
        body: '',
        reason: `curl error: ${err && err.message}`,
        curl_missing: err && err.code === 'ENOENT',
      });
    });

    child.on('close', (code) => {
      clearTimeout(timer);
      if (settled) return;
      const stdout = Buffer.concat(stdoutChunks).toString('utf8');
      const stderr = Buffer.concat(stderrChunks).toString('utf8');

      if (killedByTimeout) {
        finish({
          ok: false,
          body: '',
          reason: `timeout after ${timeoutMs}ms`,
        });
        return;
      }

      const markerIdx = stdout.lastIndexOf(`\n${statusMarker}:`);
      const status =
        markerIdx >= 0
          ? Number.parseInt(
              stdout.slice(markerIdx + `\n${statusMarker}:`.length).trim(),
              10,
            )
          : 0;
      const respBody = markerIdx >= 0 ? stdout.slice(0, markerIdx) : stdout;

      if (status >= 200 && status < 300) {
        finish({ ok: true, body: respBody, reason: '' });
        return;
      }
      if (status === 0) {
        // curl exited without an HTTP response. Map exit codes 6
        // (couldn't resolve host) and 7 (couldn't connect) to a
        // transient-classifiable reason so the retry layer engages.
        const exitNote = code !== 0 ? `exit ${code}` : 'no response';
        const stderrSnip = stderr.trim().slice(0, 200) || 'no stderr';
        finish({
          ok: false,
          body: respBody,
          reason: `curl ${exitNote}: ${stderrSnip}`,
        });
        return;
      }
      finish({
        ok: false,
        body: respBody,
        reason: `orchestrator HTTP ${status}`,
      });
    });

    try {
      child.stdin.on('error', (err) => {
        // Common when curl exits early (e.g. before reading stdin).
        logDebug(`curl stdin write error: ${err && err.message}`);
      });
      child.stdin.end(payload);
    } catch (err) {
      logDebug(`curl stdin end failed: ${err && err.message}`);
    }
  });
}

// ---------------------------------------------------------------------------
// dispatchHookViaNodeHttps — original ``node:https`` transport, kept as
// the fallback for environments without curl. Cannot honor
// ``HTTPS_PROXY`` env vars without external libs, so it WILL fail in
// Cowork-style sandboxes. Use only when a proxy is not required.
// ---------------------------------------------------------------------------
function dispatchHookViaNodeHttps(target, payload, timeoutMs, headers) {
  const lib = target.protocol === 'https:' ? https : http;
  const body = Buffer.from(payload, 'utf8');

  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };

    const req = lib.request(
      {
        method: 'POST',
        hostname: target.hostname,
        port: target.port || (target.protocol === 'https:' ? 443 : 80),
        path: target.pathname + target.search,
        headers: {
          ...(headers || { 'Content-Type': 'application/json' }),
          'Content-Length': body.length,
        },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const respBody = Buffer.concat(chunks).toString('utf8');
          const status = res.statusCode || 0;
          if (status >= 200 && status < 300) {
            finish({ ok: true, body: respBody, reason: '' });
          } else {
            finish({
              ok: false,
              body: respBody,
              reason: `orchestrator HTTP ${status}`,
            });
          }
        });
        res.on('error', (err) =>
          finish({
            ok: false,
            body: '',
            reason: `response error: ${err && err.message}`,
          })
        );
      }
    );
    req.on('error', (err) =>
      finish({
        ok: false,
        body: '',
        reason: `request error: ${err && err.message}`,
      })
    );
    req.setTimeout(timeoutMs, () => {
      req.destroy(new Error(`timeout after ${timeoutMs}ms`));
    });
    req.write(body);
    req.end();
  });
}

// ---------------------------------------------------------------------------
// dispatchHookWithRetry — call ``dispatchHook`` up to ``1 + maxRetries``
// times, retrying ONLY on transient network-layer reasons. HTTP errors
// from the orchestrator (4xx/5xx) are real answers and pass through on
// the first attempt.
//
// Why we need this:
// Cowork's egress sandbox spins up a fresh DNS resolver per session.
// The very first ``getaddrinfo`` against a freshly-allowlisted host
// frequently fails with ``EAI_AGAIN`` because the upstream resolver
// hasn't warmed yet. Without a retry, that one-off infrastructure
// hiccup trips ``first-fail-closed`` and the user sees a red deny box
// for a perfectly legitimate request. One retry with 150ms backoff
// papers over the cold-resolver case (the second lookup almost always
// resolves) without making the hook materially slower in the happy
// path (no retry happens when the first attempt succeeds).
// ---------------------------------------------------------------------------
async function dispatchHookWithRetry(agent, event, payload, options) {
  const maxRetries = (options && options.maxRetries) ?? parseMaxRetries();
  let lastResult;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    lastResult = await dispatchHook(agent, event, payload, options);
    if (lastResult.ok) return lastResult;
    if (!isTransientReason(lastResult.reason)) return lastResult;
    if (attempt < maxRetries) {
      logDebug(
        `transient dispatch error (attempt ${attempt + 1}/${maxRetries + 1}): ` +
          `${lastResult.reason}; retrying after ${RETRY_BACKOFF_MS}ms`
      );
      await new Promise((r) => setTimeout(r, RETRY_BACKOFF_MS));
    }
  }
  return lastResult;
}

// ---------------------------------------------------------------------------
// main — CLI entry. Order: read stdin → augment → dispatch (with retry
// on transient network errors) → apply failure policy. The hook trusts
// the host's matcher to filter non-MCP tool names before invoking us;
// see top-of-file note.
// ---------------------------------------------------------------------------
async function main() {
  applyBakedConfigToEnv(loadBakedConfig());

  const agent = process.argv[2] || 'claude-code';
  const event = process.argv[3] || 'PreToolUse';
  const failureMode = parseFailureMode();

  const raw = await readStdin();
  const parsed = safeParse(raw);
  const sessionId =
    (isPlainObject(parsed) && typeof parsed.session_id === 'string'
      ? parsed.session_id
      : '') || '';

  let payload = raw;
  try {
    payload = augmentPayload(raw);
    if (typeof payload !== 'string' || payload.length === 0) payload = raw;
  } catch (err) {
    logDebug(`augmentPayload failed: ${err && err.message}`);
    payload = raw;
  }

  const result = await dispatchHookWithRetry(agent, event, payload, {
    orchestratorUrl: process.env.EVE_ORCHESTRATOR_URL || '',
    timeoutMs: parseTimeoutMs(),
    maxRetries: parseMaxRetries(),
  });

  if (result.ok) {
    process.stdout.write(result.body);
    return;
  }

  logDebug(`dispatch failed: ${result.reason}`);
  const { body } = resolveFailureResponse(failureMode, sessionId, result.reason, event);
  process.stdout.write(body);
}

module.exports = {
  extractCallingGuid,
  extractNamespaceTools,
  injectResolutionSignals,
  augmentPayload,
  dispatchHook,
  dispatchHookViaCurl,
  dispatchHookViaNodeHttps,
  dispatchHookWithRetry,
  readTranscriptTail,
  resolveUserEmail,
  resolveFailureResponse,
  parseFailureMode,
  parseMaxRetries,
  isTransientReason,
  isMcpToolName,
  stateFilePath,
  buildRequestHeaders,
  loadBakedConfig,
  applyBakedConfigToEnv,
};

if (require.main === module) {
  main().catch((err) => {
    logDebug(`fatal: ${err && err.message}`);
    // Catastrophic path: respect failure mode best-effort. We don't
    // have a parsed session_id here, so use the global state bucket.
    const { body } = resolveFailureResponse(
      parseFailureMode(),
      '',
      `fatal: ${err && err.message}`,
      process.argv[3] || 'PreToolUse',
    );
    process.stdout.write(body);
  });
}
