param(
  [string]$Agent = "claude-code",
  [string]$EventName = "PreToolUse"
)

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$PostToolUseEvent = "PostToolUse"
$RetryBackoffMs = 150
$StateFileTtlSeconds = 3600
$FailureLogDirName = "eve-guard-hook-diagnostics"
$FailureLogFileName = "failures.jsonl"
$LastFailureFileName = "last-failure.json"
$TransientPatterns = @(
  "EAI_AGAIN", "EAI_NODATA", "EAI_NONAME", "ECONNRESET", "ECONNREFUSED",
  "ETIMEDOUT", "ENOTFOUND", "socket hang up", "timeout after \d+ms",
  "curl exit (6|7|18|28|35|52|55|56|92)\b"
)

function Get-EnvValue([string]$Name, [string]$Default = "") {
  $value = [Environment]::GetEnvironmentVariable($Name)
  if ([string]::IsNullOrWhiteSpace($value)) { return $Default }
  return $value.Trim()
}

function Write-DebugLog([string]$Message) {
  if ((Get-EnvValue "EVE_HOOK_DEBUG") -eq "1") {
    [Console]::Error.WriteLine("[eve-hook] $Message")
  }
}

function Get-FailureLogDir {
  $dir = Join-Path ([IO.Path]::GetTempPath()) $FailureLogDirName
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  return $dir
}

function Get-FailureLogPath {
  return Join-Path (Get-FailureLogDir) $FailureLogFileName
}

function Get-LastFailurePath {
  return Join-Path (Get-FailureLogDir) $LastFailureFileName
}

function Truncate-Text([string]$Value, [int]$MaxLength = 700) {
  if ([string]::IsNullOrEmpty($Value)) { return "" }
  if ($Value.Length -le $MaxLength) { return $Value }
  return $Value.Substring(0, $MaxLength) + "...[truncated]"
}

function Read-JsonObject([string]$Text) {
  try { return $Text | ConvertFrom-Json } catch { return $null }
}

function Has-Property($Object, [string]$Name) {
  return $null -ne $Object -and $null -ne $Object.PSObject.Properties[$Name]
}

function Get-Property($Object, [string]$Name, $Default = $null) {
  if (Has-Property $Object $Name) { return $Object.PSObject.Properties[$Name].Value }
  return $Default
}

function Set-Property($Object, [string]$Name, $Value) {
  if (Has-Property $Object $Name) {
    $Object.PSObject.Properties[$Name].Value = $Value
    return
  }
  $Object | Add-Member -NotePropertyName $Name -NotePropertyValue $Value
}

function Get-PayloadKeys($Payload) {
  if ($null -eq $Payload) { return @() }
  return @($Payload.PSObject.Properties | ForEach-Object { $_.Name })
}

function Has-AnyProperty($Object, [string[]]$Names) {
  foreach ($name in $Names) {
    if (Has-Property $Object $name) { return $true }
  }
  return $false
}

function Extract-HttpStatus([string]$Reason) {
  $match = [regex]::Match($Reason, "Eve Guard HTTP (\d+)")
  if ($match.Success) { return [int]$match.Groups[1].Value }
  return $null
}

function Extract-ResponsePreview([string]$Reason) {
  $match = [regex]::Match($Reason, "Eve Guard HTTP \d+:\s*(.*)$")
  if ($match.Success) { return Truncate-Text $match.Groups[1].Value }
  return ""
}

function Get-ConfigPath {
  $root = Get-EnvValue "CLAUDE_PLUGIN_ROOT"
  if ($root) {
    $candidate = Join-Path $root "eve.config.json"
    if (Test-Path -LiteralPath $candidate) { return $candidate }
  }
  # Cursor sets no plugin-root env, so discover the config relative to the
  # script: the launcher is at <root>/hooks/cursor-hook.ps1 and the config
  # at <root>/eve.config.json, i.e. $PSScriptRoot/../eve.config.json. The
  # same path also resolves for Claude, so this is a safe superset.
  if ($PSScriptRoot) {
    $candidate = Join-Path (Split-Path -Parent $PSScriptRoot) "eve.config.json"
    if (Test-Path -LiteralPath $candidate) { return $candidate }
  }
  return $null
}

function Read-BakedConfig {
  $path = Get-ConfigPath
  if (-not $path) { return $null }
  return Read-JsonObject ([IO.File]::ReadAllText($path))
}

function Set-EnvIfMissing([string]$Name, $Value) {
  if ($null -eq $Value -or (Get-EnvValue $Name)) { return }
  Set-Item -Path "Env:$Name" -Value ([string]$Value)
}

function Apply-BakedConfig($Config) {
  if ($null -eq $Config) { return }
  Set-EnvIfMissing "EVE_ORCHESTRATOR_URL" (Get-Property $Config "orchestrator_url")
  Set-EnvIfMissing "EVE_HOOK_TENANT_ID" (Get-Property $Config "tenant_id")
  Set-EnvIfMissing "EVE_HOOK_PLUGIN_ID" (Get-Property $Config "plugin_id")
  Set-EnvIfMissing "EVE_HOOK_CONFIG_HASH" (Get-Property $Config "config_hash")
  Set-EnvIfMissing "EVE_HOOK_TIMEOUT_S" (Get-Property $Config "timeout_s")
  Set-EnvIfMissing "EVE_HOOK_FAILURE_MODE" (Get-Property $Config "failure_mode")
  Set-EnvIfMissing "EVE_HOOK_MAX_RETRIES" (Get-Property $Config "max_retries")
  Set-EnvIfMissing "EVE_HOOK_DEBUG" $(if ((Get-Property $Config "debug") -eq $true) { "1" } else { "0" })
  Set-EnvIfMissing "EVE_HOOK_DISABLE_CURL" $(if ((Get-Property $Config "disable_curl") -eq $true) { "1" } else { "0" })
}

function Get-TimeoutSeconds {
  $raw = Get-EnvValue "EVE_HOOK_TIMEOUT_S" "8"
  $value = 8
  [void][int]::TryParse($raw, [ref]$value)
  return [Math]::Min(30, [Math]::Max(1, $value))
}

function Get-MaxRetries {
  $raw = Get-EnvValue "EVE_HOOK_MAX_RETRIES" "1"
  $value = 1
  [void][int]::TryParse($raw, [ref]$value)
  return [Math]::Min(3, [Math]::Max(0, $value))
}

function Get-FailureMode {
  $mode = Get-EnvValue "EVE_HOOK_FAILURE_MODE" "fail-closed"
  if (@("fail-open", "fail-closed", "first-fail-closed") -contains $mode) { return $mode }
  return "fail-closed"
}

# Cursor fires "after"/"post" events once the tool already ran; those take a
# response-phase block shape rather than a pre-tool permission verdict.
function Test-CursorPostTool([string]$Event) {
  return @("afterMCPExecution", "postToolUse", "afterShellExecution", "afterFileEdit", "postToolUseFailure") -contains $Event
}

# Agent-native "no objection" reply for the fail-open path. Cursor pre-tool
# hooks want an explicit allow; everything else treats "{}" as pass-through.
function New-AllowResponse([string]$Event) {
  if ($Agent -eq "cursor" -and -not (Test-CursorPostTool $Event)) {
    return @{ permission = "allow"; continue = $true } | ConvertTo-Json -Compress
  }
  return "{}"
}

function New-DenyResponse([string]$Reason, [string]$Event) {
  if ($Agent -eq "cursor") {
    if (Test-CursorPostTool $Event) {
      return @{
        updated_mcp_tool_output = @{
          isError = $true
          content = @(@{ type = "text"; text = $Reason })
          _eve_guard = @{ blocked = $true; phase = "response" }
        }
        additional_context = $Reason
      } | ConvertTo-Json -Compress -Depth 10
    }
    return @{
      permission = "deny"
      continue = $true
      user_message = $Reason
      agent_message = $Reason
    } | ConvertTo-Json -Compress -Depth 10
  }
  if ($Event -eq $PostToolUseEvent) {
    return @{
      decision = "block"
      reason = $Reason
      hookSpecificOutput = @{
        hookEventName = $PostToolUseEvent
        additionalContext = $Reason
        updatedToolOutput = $Reason
      }
    } | ConvertTo-Json -Compress -Depth 10
  }
  return @{
    continue = $false
    stopReason = $Reason
    hookSpecificOutput = @{
      hookEventName = "PreToolUse"
      permissionDecision = "deny"
      permissionDecisionReason = $Reason
    }
  } | ConvertTo-Json -Compress -Depth 10
}

function Write-FailureLog([string]$Reason, [string]$Event, $Payload = $null) {
  try {
    $transcriptPath = Get-Property $Payload "transcript_path" (Get-Property $Payload "transcriptPath" "")
    $record = @{
      timestamp = [DateTimeOffset]::UtcNow.ToString("o")
      event = $Event
      agent = $Agent
      hook_runtime = "powershell"
      reason = $Reason
      http_status = Extract-HttpStatus $Reason
      response_preview = Extract-ResponsePreview $Reason
      plugin_id = Get-EnvValue "EVE_HOOK_PLUGIN_ID"
      config_hash = Get-EnvValue "EVE_HOOK_CONFIG_HASH"
      eve_guard_url = Get-EnvValue "EVE_ORCHESTRATOR_URL"
      plugin_root = Get-EnvValue "CLAUDE_PLUGIN_ROOT"
      session_id = Get-Property $Payload "session_id" ""
      tool_name = Get-Property $Payload "tool_name" (Get-Property $Payload "toolName" "")
      tool_use_id = Get-Property $Payload "tool_use_id" (Get-Property $Payload "toolUseId" "")
      payload_keys = @(Get-PayloadKeys $Payload)
      has_tool_input = Has-AnyProperty $Payload @("tool_input", "toolInput", "input")
      has_tool_response = Has-AnyProperty $Payload @("tool_response", "toolResponse", "tool_output", "toolOutput")
      transcript_path = $transcriptPath
      transcript_path_exists = ($transcriptPath -and (Test-Path -LiteralPath $transcriptPath))
      failure_mode = Get-FailureMode
      timeout_s = Get-TimeoutSeconds
      max_retries = Get-MaxRetries
      curl_disabled = ((Get-EnvValue "EVE_HOOK_DISABLE_CURL") -eq "1")
      powershell_version = [string]$PSVersionTable.PSVersion
      powershell_edition = [string]$PSVersionTable.PSEdition
      log_file = Get-FailureLogPath
      last_failure_file = Get-LastFailurePath
    }
    $json = $record | ConvertTo-Json -Compress -Depth 12
    [IO.File]::AppendAllText((Get-FailureLogPath), $json + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText((Get-LastFailurePath), $json, [Text.UTF8Encoding]::new($false))
  } catch {}
}

function Format-FailureReason([string]$Reason, [string]$Event) {
  $logPath = Get-LastFailurePath
  return "Eve Guard blocked this $Event hook locally because it could not verify the tool call with Eve Guard. Reason: $(Truncate-Text $Reason). Diagnostics: $logPath"
}

function Get-StateFile([string]$SessionId) {
  $key = if ([string]::IsNullOrWhiteSpace($SessionId)) { "global" } else { $SessionId }
  $sha = [Security.Cryptography.SHA256]::Create()
  $bytes = [Text.Encoding]::UTF8.GetBytes($key)
  $hash = [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace("-", "").ToLowerInvariant().Substring(0, 16)
  return Join-Path (Get-EnvValue "EVE_HOOK_STATE_DIR" ([IO.Path]::GetTempPath())) "eve-hook-degraded-$hash.flag"
}

function Test-Degraded([string]$SessionId) {
  $file = Get-StateFile $SessionId
  if (-not (Test-Path -LiteralPath $file)) { return $false }
  if (((Get-Date) - (Get-Item -LiteralPath $file).LastWriteTime).TotalSeconds -gt $StateFileTtlSeconds) {
    Remove-Item -LiteralPath $file -Force
    return $false
  }
  return $true
}

function Set-Degraded([string]$SessionId) {
  $file = Get-StateFile $SessionId
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $file) | Out-Null
  [IO.File]::WriteAllText($file, [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds().ToString())
}

function Resolve-FailureResponse([string]$Mode, [string]$SessionId, [string]$Reason, [string]$Event, $Payload = $null) {
  Write-FailureLog $Reason $Event $Payload
  $visibleReason = Format-FailureReason $Reason $Event
  if ($Mode -eq "fail-open") { return (New-AllowResponse $Event) }
  if ($Mode -eq "fail-closed") { return New-DenyResponse $visibleReason $Event }
  if (Test-Degraded $SessionId) { return (New-AllowResponse $Event) }
  Set-Degraded $SessionId
  return New-DenyResponse "$visibleReason Following requests in this session will be fail-open." $Event
}

function Get-UserEmail($Payload) {
  $explicit = Get-Property $Payload "user_email" ""
  if (-not [string]::IsNullOrWhiteSpace($explicit)) { return $explicit.Trim() }
  foreach ($name in @("CURSOR_USER_EMAIL", "CLAUDE_CODE_USER_EMAIL", "CLAUDE_USER_EMAIL", "USER_EMAIL")) {
    $value = Get-EnvValue $name
    if ($value) { return $value }
  }
  return Get-EnvelopeEmail (Get-Property $Payload "transcript_path" "")
}

function Get-EnvelopeEmail([string]$TranscriptPath) {
  if (-not $TranscriptPath) { return "" }
  $dir = Split-Path -Parent $TranscriptPath
  for ($i = 0; $i -lt 8 -and $dir; $i++) {
    $candidate = "$dir.json"
    if ((Split-Path -Leaf $dir).StartsWith("local_") -and (Test-Path -LiteralPath $candidate)) {
      $obj = Read-JsonObject ([IO.File]::ReadAllText($candidate))
      $email = Get-Property $obj "emailAddress" ""
      if ($email) { return $email.Trim() }
      $accountEmail = Get-Property (Get-Property $obj "account") "email" ""
      if ($accountEmail) { return $accountEmail.Trim() }
    }
    $parent = Split-Path -Parent $dir
    if ($parent -eq $dir) { break }
    $dir = $parent
  }
  return ""
}

function Get-CallingGuid($Payload) {
  $toolName = Get-Property $Payload "tool_name" (Get-Property $Payload "toolName" "")
  $match = [regex]::Match([string]$toolName, "^mcp__([0-9a-fA-F-]{36})__")
  if ($match.Success) { return $match.Groups[1].Value.ToLowerInvariant() }
  return ""
}

function Get-DeltaNames($EventObject) {
  $candidates = @()
  $attachment = Get-Property $EventObject "attachment"
  if ((Get-Property $attachment "type") -eq "deferred_tools_delta") { $candidates += $attachment }
  $nested = Get-Property (Get-Property $EventObject "message") "attachment"
  if ((Get-Property $nested "type") -eq "deferred_tools_delta") { $candidates += $nested }
  $direct = Get-Property $EventObject "deferred_tools_delta"
  if ($null -ne $direct) { $candidates += $direct }
  return Read-DeltaNames $candidates
}

function Read-DeltaNames($Deltas) {
  $names = @()
  foreach ($delta in $Deltas) {
    foreach ($field in @("addedNames", "tools")) {
      foreach ($entry in @(Get-Property $delta $field @())) {
        if ($entry -is [string]) { $names += $entry }
        else { $name = Get-Property $entry "name" ""; if ($name) { $names += $name } }
      }
    }
  }
  return $names
}

function Get-InitToolNames($EventObject) {
  if ((Get-Property $EventObject "type") -ne "system") { return @() }
  if ((Get-Property $EventObject "subtype") -ne "init") { return @() }
  $names = @()
  foreach ($entry in @(Get-Property $EventObject "tools" @())) {
    if ($entry -is [string]) { $names += $entry }
    else { $name = Get-Property $entry "name" ""; if ($name) { $names += $name } }
  }
  return $names
}

function Get-TranscriptToolNames($EventObject) {
  $names = @()
  $names += @(Get-DeltaNames $EventObject)
  $names += @(Get-InitToolNames $EventObject)
  return $names
}

function Get-NamespaceTools([string]$TranscriptPath, [string]$Guid) {
  if (-not $TranscriptPath -or -not $Guid -or -not (Test-Path -LiteralPath $TranscriptPath)) { return @() }
  $prefix = "mcp__$Guid`__"
  $lines = Get-Content -LiteralPath $TranscriptPath -Tail 800
  [array]::Reverse($lines)
  foreach ($line in $lines) {
    $obj = Read-JsonObject $line
    $found = @(Get-TranscriptToolNames $obj | Where-Object { $_.StartsWith($prefix) })
    if ($found.Count -gt 0) { return @($found | ForEach-Object { $_.Substring($prefix.Length) } | Select-Object -Unique) }
  }
  return @()
}

function Get-ClaudeAuditRoots {
  $roots = @()
  foreach ($base in @($env:APPDATA, $env:LOCALAPPDATA)) {
    if ([string]::IsNullOrWhiteSpace($base)) { continue }
    $roots += Join-Path $base "Claude\local-agent-mode-sessions"
    $packages = Join-Path $base "Packages"
    if (Test-Path -LiteralPath $packages) {
      foreach ($pkg in Get-ChildItem -LiteralPath $packages -Directory -Filter "Claude_*" -ErrorAction SilentlyContinue) {
        $roots += Join-Path $pkg.FullName "LocalCache\Roaming\Claude\local-agent-mode-sessions"
      }
    }
  }
  if (-not [string]::IsNullOrWhiteSpace($env:USERPROFILE)) {
    $roots += Join-Path $env:USERPROFILE ".claude"
  }
  if (Test-Path -LiteralPath "C:\Users") {
    foreach ($profile in Get-ChildItem -LiteralPath "C:\Users" -Directory -ErrorAction SilentlyContinue) {
      $roots += Join-Path $profile.FullName "AppData\Roaming\Claude\local-agent-mode-sessions"
      $packages = Join-Path $profile.FullName "AppData\Local\Packages"
      if (Test-Path -LiteralPath $packages) {
        foreach ($pkg in Get-ChildItem -LiteralPath $packages -Directory -Filter "Claude_*" -ErrorAction SilentlyContinue) {
          $roots += Join-Path $pkg.FullName "LocalCache\Roaming\Claude\local-agent-mode-sessions"
        }
      }
    }
  }
  return $roots | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique
}

function Find-FallbackAuditPath([string]$SessionId) {
  if ([string]::IsNullOrWhiteSpace($SessionId)) { return "" }
  foreach ($root in Get-ClaudeAuditRoots) {
    $files = Get-ChildItem -LiteralPath $root -Recurse -Filter audit.jsonl -File -ErrorAction SilentlyContinue |
      Sort-Object LastWriteTime -Descending |
      Select-Object -First 80
    foreach ($file in $files) {
      try {
        if (Select-String -LiteralPath $file.FullName -Pattern $SessionId -SimpleMatch -Quiet) { return $file.FullName }
      } catch {}
    }
  }
  return ""
}

function Add-ResolutionSignals([string]$Raw) {
  $payload = Read-JsonObject $Raw
  if ($null -eq $payload) { return $Raw }
  $email = Get-UserEmail $payload
  if ($email -and -not (Get-Property $payload "user_email" "")) { Set-Property $payload "user_email" $email }
  $guid = Get-CallingGuid $payload
  if ($guid) {
    Set-Property $payload "eve_mcp_directory_uuid" $guid
    $path = Get-Property $payload "transcript_path" (Get-Property $payload "transcriptPath" "")
    $tools = @(Get-NamespaceTools $path $guid)
    if ($tools.Count -eq 0) {
      $fallbackPath = Find-FallbackAuditPath (Get-Property $payload "session_id" "")
      $fallbackTools = @(Get-NamespaceTools $fallbackPath $guid)
      if ($fallbackTools.Count -gt 0) { $tools = $fallbackTools }
    }
    if ($tools.Count -gt 0) { Set-Property $payload "eve_mcp_namespace_tools" $tools }
  }
  return ($payload | ConvertTo-Json -Compress -Depth 100)
}

function Test-Transient([string]$Reason) {
  foreach ($pattern in $TransientPatterns) {
    if ($Reason -match $pattern) { return $true }
  }
  return $false
}

function Get-Endpoint([string]$BaseUrl, [string]$HookAgent, [string]$HookEvent) {
  if (-not $BaseUrl) { throw "EVE_ORCHESTRATOR_URL not set" }
  $base = $BaseUrl.TrimEnd("/")
  return "$base/hooks/$([uri]::EscapeDataString($HookAgent))/$([uri]::EscapeDataString($HookEvent))"
}

function Invoke-CurlHookRequest([string]$Body) {
  if ((Get-EnvValue "EVE_HOOK_DISABLE_CURL") -eq "1") { throw "curl disabled" }
  $curl = Get-Command "curl.exe" -ErrorAction SilentlyContinue
  if ($null -eq $curl) { throw "curl.exe not found" }

  $endpoint = Get-Endpoint (Get-EnvValue "EVE_ORCHESTRATOR_URL") $Agent $EventName
  $bodyFile = [IO.Path]::GetTempFileName()
  $errFile = [IO.Path]::GetTempFileName()
  [IO.File]::WriteAllText($bodyFile, $Body, [Text.UTF8Encoding]::new($false))
  try {
    $args = @(
      "--silent", "--show-error",
      "--max-time", "$(Get-TimeoutSeconds)",
      "-X", "POST",
      "-H", "Content-Type: application/json; charset=utf-8"
    )
    $pluginId = Get-EnvValue "EVE_HOOK_PLUGIN_ID"
    if ($pluginId -match "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$") {
      $args += @("-H", "X-Eve-Hook-Plugin-Id: $pluginId")
    }
    $args += @("--data-binary", "@$bodyFile", "-w", "`n__EVE_HOOK_STATUS__:%{http_code}", $endpoint)
    $response = & $curl.Source @args 2>$errFile
    $exitCode = $LASTEXITCODE
    $responseText = ($response -join "`n")
    if ($exitCode -ne 0) {
      $stderr = if (Test-Path -LiteralPath $errFile) { [IO.File]::ReadAllText($errFile).Trim() } else { "" }
      throw "curl exit ${exitCode}: $(if ($stderr) { $stderr } else { 'no stderr' })"
    }
    $statusMatch = [regex]::Match($responseText, "(?s)(?:^|\r?\n)__EVE_HOOK_STATUS__:(\d+)\s*$")
    if (-not $statusMatch.Success) { throw "curl missing HTTP status trailer" }
    $status = $statusMatch.Groups[1].Value
    $content = $responseText.Substring(0, $statusMatch.Index).TrimEnd()
    if (-not $status -or [int]$status -lt 200 -or [int]$status -ge 300) {
      throw "Eve Guard HTTP $(if ($status) { $status } else { '0' }): $(Truncate-Text $content)"
    }
    return $content
  } finally {
    Remove-Item -LiteralPath $bodyFile, $errFile -Force -ErrorAction SilentlyContinue
  }
}

function Invoke-HookRequest([string]$Body) {
  try { return Invoke-CurlHookRequest $Body } catch { Write-DebugLog "curl path failed: $($_.Exception.Message)" }
  $endpoint = Get-Endpoint (Get-EnvValue "EVE_ORCHESTRATOR_URL") $Agent $EventName
  $headers = @{ "Content-Type" = "application/json; charset=utf-8" }
  $pluginId = Get-EnvValue "EVE_HOOK_PLUGIN_ID"
  if ($pluginId -match "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$") {
    $headers["X-Eve-Hook-Plugin-Id"] = $pluginId
  }
  try {
    $bodyBytes = [Text.Encoding]::UTF8.GetBytes($Body)
    $response = Invoke-WebRequest -Uri $endpoint -Method Post -Headers $headers -Body $bodyBytes -TimeoutSec (Get-TimeoutSeconds) -UseBasicParsing -ErrorAction Stop
  } catch {
    throw (Format-WebExceptionReason $_.Exception)
  }
  if ([int]$response.StatusCode -lt 200 -or [int]$response.StatusCode -ge 300) { throw "Eve Guard HTTP $($response.StatusCode)" }
  return [string]$response.Content
}

function Format-WebExceptionReason($Exception) {
  $response = $Exception.Response
  if ($null -eq $response) { return $Exception.Message }
  $statusCode = [int]$response.StatusCode
  $body = ""
  try {
    $stream = $response.GetResponseStream()
    if ($null -ne $stream) {
      $reader = [IO.StreamReader]::new($stream)
      $body = $reader.ReadToEnd()
    }
  } catch {}
  return "Eve Guard HTTP ${statusCode}: $(Truncate-Text $body)"
}

function Invoke-WithRetry([string]$Body) {
  $maxRetries = Get-MaxRetries
  for ($attempt = 0; $attempt -le $maxRetries; $attempt++) {
    try { return @{ ok = $true; body = (Invoke-HookRequest $Body); reason = "" } }
    catch {
      $reason = $_.Exception.Message
      if (-not (Test-Transient $reason) -or $attempt -eq $maxRetries) { return @{ ok = $false; body = ""; reason = $reason } }
      Start-Sleep -Milliseconds $RetryBackoffMs
    }
  }
}

function Main {
  Apply-BakedConfig (Read-BakedConfig)
  $raw = [Console]::In.ReadToEnd()
  $parsed = Read-JsonObject $raw
  $sessionId = Get-Property $parsed "session_id" ""
  $payload = Add-ResolutionSignals $raw
  $enriched = Read-JsonObject $payload
  $result = Invoke-WithRetry $payload
  if ($result.ok) { [Console]::Out.Write($result.body); exit 0 }
  Write-DebugLog "dispatch failed: $($result.reason)"
  [Console]::Out.Write((Resolve-FailureResponse (Get-FailureMode) $sessionId $result.reason $EventName $enriched))
  exit 0
}

try { Main } catch {
  [Console]::Out.Write((Resolve-FailureResponse (Get-FailureMode) "" "fatal: $($_.Exception.Message)" $EventName))
  exit 0
}
